package com.app.socialmedialikes;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Login extends AppCompatActivity implements View.OnClickListener {

    String url = "https://script.google.com/macros/s/AKfycbw3IM-c3qpwnv5kTlX3PrzBA3NIDAuca2aW4g8aYkz6Lp0Rrw/exec";
    EditText login_editTextUsername;
    TextInputLayout usernameLayout,passwordLayout;
    TextInputEditText login_editTextPassword;
    Button signin;
    TextView signup;
    ProgressDialog loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        login_editTextUsername = findViewById(R.id.username_login);
        login_editTextPassword = findViewById(R.id.password_login);

        usernameLayout = findViewById(R.id.username_wrapper);
        passwordLayout = findViewById(R.id.password_wrapper);

        signin = findViewById(R.id.signin);
        signin.setOnClickListener(this);

        signup = findViewById(R.id.signup);
        signup.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        if (v == signin){
            checkFields();
        }
        else if (v == signup){
            startActivity(new Intent(this,AddItem.class));
        }
    }

    private void checkFields(){
        int goodToGo = 1;

        if (TextUtils.isEmpty(login_editTextUsername.getText().toString())){
//            login_editTextUsername.setError("Required Field");
            usernameLayout.setError("Required Field");
            goodToGo = 0;
        }
        else {
//            login_editTextUsername.setError(null);
            usernameLayout.setError(null);
        }
        if (TextUtils.isEmpty(login_editTextPassword.getText().toString())){
//            login_editTextPassword.setError("Required Field");
            passwordLayout.setError("Required Field");
            goodToGo = 0;
        }else {
//            login_editTextPassword.setError(null);
            passwordLayout.setError(null);
        }

        if (goodToGo == 1){
            getItems();
        }
    }

    private void getItems() {

        loading = ProgressDialog.show(this,"Sigining You in","Please wait...");
        final String username = login_editTextUsername.getText().toString().trim();
        final String password = login_editTextPassword.getText().toString().trim();


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url +"?action=login&usrnm="+ username + "&pswd=" + password,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);



    }

    private void parseItems(String jsonResponse) {
        int result = Integer.parseInt(jsonResponse);
        Log.v("Result Value: ", String.valueOf(result));
        switch (result){
            case 1:
                loading.dismiss();
                Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this,MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);

                return;
            case 404:
                loading.dismiss();
                alertDialog();
                return;
            case 401:
                loading.dismiss();
                alertDialog();

        }

    }

    private void alertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Invalid Username/Password");
        builder.setMessage(getString(R.string.invalidcredentials));

        builder.setNegativeButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
