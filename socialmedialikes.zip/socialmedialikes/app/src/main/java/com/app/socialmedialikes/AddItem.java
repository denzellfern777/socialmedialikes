package com.app.socialmedialikes;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddItem extends AppCompatActivity implements View.OnClickListener {

    String url = "https://script.google.com/macros/s/AKfycbw3IM-c3qpwnv5kTlX3PrzBA3NIDAuca2aW4g8aYkz6Lp0Rrw/exec";
    ProgressDialog loading;
    EditText editTextFirstName, editTextEmailAddress, editTextUsername;
    TextInputLayout nameInputLayout, emailInputLayout, usernameInputLayout, passwordInputLayout;
    TextInputEditText editTextPassword;
    MaterialButton btnAddItem;
    boolean username_available = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);
        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        editTextFirstName = findViewById(R.id.fname_et);
        editTextEmailAddress = findViewById(R.id.email_et);
        editTextUsername = findViewById(R.id.uname_et);
        editTextPassword = findViewById(R.id.password_et);

        nameInputLayout = findViewById(R.id.name_wrapper_register);
        emailInputLayout = findViewById(R.id.email_wrapper_register);
        usernameInputLayout = findViewById(R.id.username_wrapper_register);
        passwordInputLayout = findViewById(R.id.password_wrapper_register);

        btnAddItem = findViewById(R.id.btn_add_item);
        btnAddItem.setOnClickListener(this);
    }


    private void checkFields() {

        int goodToGo = 1;
        if (TextUtils.isEmpty(editTextFirstName.getText().toString())) {
//            editTextFirstName.setError("Required Field");
            nameInputLayout.setError("Required Field");
            goodToGo = 0;
        } else {
            nameInputLayout.setError(null);
        }
        if (TextUtils.isEmpty(editTextEmailAddress.getText().toString())) {
            emailInputLayout.setError("Required Field");
            goodToGo = 0;
        } else {
            emailInputLayout.setError(null);
        }
        if (TextUtils.isEmpty(editTextPassword.getText().toString())) {
            passwordInputLayout.setError("Required Field");
            goodToGo = 0;
        } else {
            passwordInputLayout.setError(null);
        }
        if (TextUtils.isEmpty(editTextUsername.getText().toString())) {
            usernameInputLayout.setError("Required Field");
            goodToGo = 0;
        } else if (editTextUsername.getText().toString().trim().length() < 5) {
            usernameInputLayout.setError("Minimum 5 characters required");
            goodToGo = 0;
        } else {
            usernameInputLayout.setError(null);
        }
        if (goodToGo == 1) {
            getItems();
        }

    }

    private void post() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(AddItem.this, response, Toast.LENGTH_LONG).show();
                        Intent i = new Intent(getApplicationContext(), Login.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parmas = new HashMap<>();

                final String fname = editTextFirstName.getText().toString().trim();
                final String email = editTextEmailAddress.getText().toString().trim();
                final String uname = editTextUsername.getText().toString().trim();
                final String pswd = editTextPassword.getText().toString().trim();

                //here we pass params
                parmas.put("action", "addItem");
                parmas.put("uname", uname);
                parmas.put("fname", fname);
                parmas.put("email", email);
                parmas.put("pswd", pswd);

                return parmas;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);
    }

    private boolean getItems() {
        loading = ProgressDialog.show(this, "Signing you up", "Please wait");
        final String uname = editTextUsername.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url + "?action=searchItems&search=" + uname,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);

        return username_available;

    }


    private void parseItems(String jsonResponse) {
        int result = Integer.parseInt(jsonResponse);
        if (result == 1) {

            loading.dismiss();
            usernameInputLayout.setError("That username is taken. Try another");
            username_available = false;

        } else {
            usernameInputLayout.setError(null);
            username_available = true;
            post();
        }

    }

    @Override
    public void onClick(View v) {
        if (v == btnAddItem) {
            checkFields();

            //Define what to do when button is clicked
        }

    }
}
