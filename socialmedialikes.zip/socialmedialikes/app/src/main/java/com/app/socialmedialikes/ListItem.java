package com.app.socialmedialikes;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import me.zhanghai.android.materialprogressbar.MaterialProgressBar;

public class ListItem extends AppCompatActivity {

    String url = "https://script.google.com/macros/s/AKfycbw3IM-c3qpwnv5kTlX3PrzBA3NIDAuca2aW4g8aYkz6Lp0Rrw/exec";
    ListView listView;
    ListAdapter adapter;
    ProgressDialog loading;
    MaterialProgressBar materialProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_item);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.items_lv);
        materialProgressBar = findViewById(R.id.material_progressbar_horizontal);

        getItems();

    }

    private void getItems() {

//        loading =  ProgressDialog.show(this,"Loading","please wait",false,true);
        materialProgressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url +"?action=getItems",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);

    }


    private void parseItems(String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);

                String fname = jo.getString("fname");
                String email = jo.getString("email");
                String pswd = jo.getString("pswd");
                String uname = jo.getString("uname");


                HashMap<String, String> item = new HashMap<>();
                item.put("fname", fname);
                item.put("email", email);
                item.put("uname", uname);
                item.put("pswd", pswd);

                list.add(item);



            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.list_item,
                new String[]{"fname","email","uname","pswd"},new int[]{R.id.tv_fname,R.id.tv_email,R.id.tv_username,R.id.tv_pswd});


        listView.setAdapter(adapter);
//        loading.dismiss();

        materialProgressBar.setVisibility(View.GONE);
    }

}
